library verilog;
use verilog.vl_types.all;
entity temporizador_vlg_check_tst is
    port(
        t0              : in     vl_logic;
        t1              : in     vl_logic;
        t2              : in     vl_logic;
        t3              : in     vl_logic;
        t4              : in     vl_logic;
        t5              : in     vl_logic;
        t6              : in     vl_logic;
        t7              : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end temporizador_vlg_check_tst;
