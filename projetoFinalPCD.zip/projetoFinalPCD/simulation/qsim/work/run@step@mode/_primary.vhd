library verilog;
use verilog.vl_types.all;
entity runStepMode is
    port(
        clkDiv          : in     vl_logic;
        runDebug        : in     vl_logic;
        sel             : in     vl_logic;
        clkOut          : out    vl_logic
    );
end runStepMode;
