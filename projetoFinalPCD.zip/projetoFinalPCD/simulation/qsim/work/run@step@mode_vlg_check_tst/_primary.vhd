library verilog;
use verilog.vl_types.all;
entity runStepMode_vlg_check_tst is
    port(
        clkOut          : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end runStepMode_vlg_check_tst;
