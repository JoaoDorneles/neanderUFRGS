library verilog;
use verilog.vl_types.all;
entity runStepMode_vlg_sample_tst is
    port(
        clkDiv          : in     vl_logic;
        runDebug        : in     vl_logic;
        sel             : in     vl_logic;
        sampler_tx      : out    vl_logic
    );
end runStepMode_vlg_sample_tst;
